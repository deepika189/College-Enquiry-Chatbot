import nltk
from nltk.stem import WordNetLemmatizer
lemmatizer = WordNetLemmatizer()
import pickle
import numpy as np

from keras.models import load_model
model = load_model('chatbot_model.h5')
import json
import random
intents = json.loads(open('intents.json').read())
words = pickle.load(open('words.pkl','rb'))
classes = pickle.load(open('classes.pkl','rb'))


def clean_up_sentence(sentence):
    # tokenize the pattern - split words into array
    sentence_words = nltk.word_tokenize(sentence)
    # stem each word - create short form for word
    sentence_words = [lemmatizer.lemmatize(word.lower()) for word in sentence_words]
    return sentence_words

# return bag of words array: 0 or 1 for each word in the bag that exists in the sentence

def bow(sentence, words, show_details=True):
    # tokenize the pattern
    sentence_words = clean_up_sentence(sentence)
    # bag of words - matrix of N words, vocabulary matrix
    bag = [0]*len(words)  
    for s in sentence_words:
        for i,w in enumerate(words):
            if w == s: 
                # assign 1 if current word is in the vocabulary position
                bag[i] = 1
                if show_details:
                    print ("found in bag: %s" % w)
    return(np.array(bag))

def predict_class(sentence, model):
    # filter out predictions below a threshold
    p = bow(sentence, words,show_details=False)
    res = model.predict(np.array([p]))[0]
    ERROR_THRESHOLD = 0.25
    results = [[i,r] for i,r in enumerate(res) if r>ERROR_THRESHOLD]
    # sort by strength of probability
    results.sort(key=lambda x: x[1], reverse=True)
    return_list = []
    for r in results:
        return_list.append({"intent": classes[r[0]], "probability": str(r[1])})
    return return_list

def getResponse(ints, intents_json):
    tag = ints[0]['intent']
    list_of_intents = intents_json['intents']
    for i in list_of_intents:
        if(i['tag']== tag):
            result = random.choice(i['responses'])
            break
    return result

def chatbot_response(msg):
    ints = predict_class(msg, model)
    res = getResponse(ints, intents)
    return res


from tkinter import *  # Python 3.x
import tkinter as tk
from datetime import datetime
import textwrap
from PIL import ImageTk,Image

root = Tk()
root.title("NHITM CHATBOT")
#root.config(bg="lightblue")
frame=Frame(root,width=500,height=500)
#frame.pack(expand=True, fill=BOTH)
frame.grid(row=0,column=0,columnspan=2)

canvas = Canvas(frame, width=500, height=500, bg="#FBF681",scrollregion=(0,0,4000,4000))
#image = ImageTk.PhotoImage(file = "book1.jpg")
#canvas.create_image(0, 0, image = image, anchor = NW)
canvas.grid(row=0,column=0,columnspan=2)



bubbles = []
class BotBubble1():

    def __init__(self,master,message=""):
        msg = entry.get("1.0",'end-1c').strip()
        self.master = master
        self.frame = Frame(master,bg="blue")
        self.i = self.master.create_window(475,400,window=self.frame,anchor=E)
        Label(self.frame,text=datetime.now().strftime("%Y-%m-%d %H:%m"),font=("Arial", 7),bg="blue", fg="white").grid(row=0,column=0,sticky="w",padx=5)
        Label(self.frame, text="YOU:"+msg,font=("Century Schoolbook", 10),bg="blue", fg="white",justify=LEFT).grid(row=1, column=0,sticky="w",padx=5,pady=3)#font=("Lucida Calligraphy", 8)
        root.update_idletasks()
        self.master.create_polygon(self.draw_triangle(self.i), fill="blue", outline="blue")

    def draw_triangle(self,widget):
        x2, y1, x1, y2 = self.master.bbox(widget)
        return x1, y2 - 10, x1 + 15, y2 + 10, x1, y2

class BotBubble2():
    def __init__(self,master,message=""):
        msg = entry.get("1.0",'end-1c').strip()
        res = chatbot_response(msg)
        self.master = master
        self.frame = Frame(master,bg="white")
        self.i = self.master.create_window(30,400,window=self.frame,anchor=W)
        Label(self.frame,text=datetime.now().strftime("%Y-%m-%d %H:%m"),font=("Arial", 7),bg="white").grid(row=0,column=0,sticky="w",padx=5)
        Label(self.frame, text="BOT: " +textwrap.fill(res,60),font=("Century Schoolbook", 10),bg="white",justify=LEFT).grid(row=1, column=0,sticky="w",padx=5,pady=3) 
        root.update_idletasks()
        self.master.create_polygon(self.draw_triangle(self.i), fill="white", outline="light grey")

    def draw_triangle(self,widget):
        x1, y1, x2, y2 = self.master.bbox(widget)
        return x1, y2 - 10, x1 - 15, y2 + 10, x1, y2
#writing function for send button
def send_message():
    msg = entry.get("1.0",'end-1c').strip()
    if bubbles:
        canvas.move(ALL, 0, -65)
        canvas.config(state=NORMAL)
    a = BotBubble1(canvas,msg)
    bubbles.append(a)
    if bubbles:
        canvas.move(ALL, 0, -90)
        canvas.config(state=NORMAL)
        res = chatbot_response(msg)
    b = BotBubble2(canvas,res)
    bubbles.append(b)
    entry.delete("0.0", END)
    canvas.config(state=DISABLED)

#writing function for enter button
def send_message5(self):
    msg = entry.get("1.0",'end-1c').strip()
    if bubbles:
        canvas.move(ALL, 0, -65)
        canvas.config(state=NORMAL)
    a = BotBubble1(canvas,msg)
    bubbles.append(a)
    if bubbles:
        canvas.move(ALL, 0, -90)
        canvas.config(state=NORMAL)
        res = chatbot_response(msg)
    b = BotBubble2(canvas,res)
    bubbles.append(b)
    entry.delete("0.0", END)
    canvas.config(state=DISABLED)

#Bind scrollbar to Chat window

vbar=Scrollbar(frame,orient=VERTICAL,cursor="heart")
#vbar.pack(side=LEFT,fill=Y)
vbar.grid(row=0,column=2,sticky='ns')
vbar.config(command=canvas.yview)
canvas.configure(scrollregion=canvas.bbox("all"))
canvas.config(yscrollcommand=vbar.set)
#canvas.config(width=500,height=500)

#Create the box to enter message
"""

v = StringVar(root, value='Type your question here.')
#e = Entry(root, bd=0, bg="#C49DDD",width="25", height="2", font="Arial", textvariable=v)
entry.insert(INSERT, "Type your question here.")
"""

entry = Text(root, bd=0, bg="#9EF47E",width="42", height="6", font="Arial", wrap=WORD)
entry.grid(row=1,column=0)
#Create Button to send message
SendButton=Button(root, font=("Lucida Fax",12,'bold'), text="SEND", bd = '7', width=11, height=5, bg="#C41484",activebackground="#D83F85",fg='white',command= send_message)
SendButton.grid(row=1,column=1,columnspan=2)
#Response should also come if user hits enter
root.bind('<Return>',send_message5)
root.mainloop()
